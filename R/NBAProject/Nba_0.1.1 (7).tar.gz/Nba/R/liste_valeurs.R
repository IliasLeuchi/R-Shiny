#' description de la fonction

#' @description cette fonction permet de lister les noms des variables d'une variable
#' @param var le nom de la variable
#' @return une liste
#' @export
#'
liste_valeurs = function (var){
  data ("nba")
  res=levels(factor(nba[[var]]))
  return (res)
}
