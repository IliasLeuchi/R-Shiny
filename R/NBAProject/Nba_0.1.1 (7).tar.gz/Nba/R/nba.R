#'
#' base de donnees pour notre projet NBA
#'
#' Base comprenant 12305 informations reparties sur 22 variables
#'
#' \source www.kaggle.com
"nba"


