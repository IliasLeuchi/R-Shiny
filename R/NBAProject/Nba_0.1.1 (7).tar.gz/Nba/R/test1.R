#'fonction test
#'@param y la valeur
#'@param ychap, l'estimation
#'@param digits un nombre
#' @return t un entier

rmse2<-function(y,ychap,digits=3)
{
  t=signif(sqrt(mean((y-ychap)^2,na.rm=TRUE))
           ,digits=digits)
  return(t)
}




