#' description de la fonction

#' @description cette fonction permet de lister les noms des variables d'un tableau
#' @param fichier un tableau
#' @return une liste
#' @export
#'

lister=function(fichier){

  l=c(names(fichier))
  return (l)
}

